package com.example.project;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FoodLists extends AppCompatActivity {

    private RecyclerView.Adapter adapterFoodList;
    private int categoryId;
    private String categoryName;
    private String searchText;
    private Boolean isSearch;

    private TextView titleTxt;
    private ImageView backBtn;
    private RecyclerView foodListView;
    private ProgressBar progressBar;

    private FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_list);

        // Initialize views
        titleTxt = findViewById(R.id.titleTxt);
        backBtn = findViewById(R.id.backBtn);
        foodListView = findViewById(R.id.foodListView);
        progressBar = findViewById(R.id.progressBar);

        database = FirebaseDatabase.getInstance();

        getIntentExtra();
        initList();
    }

    private void getIntentExtra() {
        categoryId = getIntent().getIntExtra("CategoryId", 0);
        categoryName = getIntent().getStringExtra("CategoryName");
        searchText = getIntent().getStringExtra("text");
        isSearch = getIntent().getBooleanExtra("isSearch", false);

        if (categoryName != null) {
            titleTxt.setText(categoryName);
        } else {
            titleTxt.setText("Search Results");
        }

        backBtn.setOnClickListener(v -> finish());
    }

    private void initList() {
        DatabaseReference myRef = database.getReference("Foods");
        progressBar.setVisibility(View.VISIBLE);
        ArrayList<Foods> list = new ArrayList<>();

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot issue : snapshot.getChildren()) {
                        Foods food = issue.getValue(Foods.class);

                        if (food != null) {
                            if (isSearch) {
                                if (food.getTitle() != null &&
                                        food.getTitle().toLowerCase().contains(searchText.toLowerCase())) {
                                    list.add(food);
                                }
                            } else {
                                if (food.getCategoryId() == categoryId) {
                                    list.add(food);
                                }
                            }
                        }
                    }

                    if (!list.isEmpty()) {
                        foodListView.setLayoutManager(new GridLayoutManager(FoodLists.this, 2));
                        adapterFoodList = new FoodListsAdapter(list);
                        foodListView.setAdapter(adapterFoodList);
                    }

                    progressBar.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
            }
        });
    }
}
