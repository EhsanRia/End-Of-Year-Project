package com.example.project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {

    //UI elements
    private EditText email, password;
    private Button loginButton, signUpButton;
    private TextView passwordStrength;
    private ImageView eyeIcon;
    private boolean passwordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        //UI elements
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.LogInButton);
        signUpButton = findViewById(R.id.signUpButton);
        passwordStrength = findViewById(R.id.passwordStrength);
        eyeIcon = findViewById(R.id.eyeIcon);

        eyeIcon.setOnClickListener(v -> {
            if (passwordVisible) {
                password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                eyeIcon.setImageResource(R.drawable.baseline_visibility_off_24);
                passwordVisible = false;
            } else {
                password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                eyeIcon.setImageResource(R.drawable.baseline_visibilityon_24);
                passwordVisible = true;
            }
            password.setSelection(password.length());
        });

        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int after) {
                // Check password strength
                String passwordText = password.getText().toString();
                String strength = checkPasswordStrength(passwordText);
                passwordStrength.setText(strength);
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        //Login Button listener
        loginButton.setOnClickListener(v -> {
            String loginemail = email.getText().toString();
            String loginpassword = password.getText().toString();

            //Check if email field is empty
            if (loginemail.isEmpty()) {
                Toast.makeText(Login.this, "Please enter your email", Toast.LENGTH_SHORT).show();
            } else if (!Patterns.EMAIL_ADDRESS.matcher(loginemail).matches()) {
                Toast.makeText(Login.this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
            }
            // Check if password field is empty
            else if (loginpassword.isEmpty()) {
                Toast.makeText(Login.this, "Please enter your password", Toast.LENGTH_SHORT).show();
            }
            else if (loginpassword.length() < 7) {
                // Password is too short, show an error message
                Toast.makeText(Login.this, "Password must be at least 7 characters", Toast.LENGTH_SHORT).show();
            } else {

                SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("user_email", loginemail);
                editor.apply();

                Toast.makeText(Login.this, "Login successful", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Login.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        //Sign Up Button listener
        signUpButton.setOnClickListener(v -> {
            Intent intent = new Intent(Login.this, Signup.class);
            startActivity(intent);
            finish();
        });
    }

        private boolean isPasswordStrong(String password) {
            boolean hasUpperCase = false;
            boolean hasLowerCase = false;
            boolean hasDigit = false;
            boolean hasSpecialChar = false;

            for (int i = 0; i < password.length(); i++) {
                char c = password.charAt(i);
                if (Character.isUpperCase(c)) hasUpperCase = true;
                if (Character.isLowerCase(c)) hasLowerCase = true;
                if (Character.isDigit(c)) hasDigit = true;
                if (!Character.isLetterOrDigit(c)) hasSpecialChar = true;
            }

            return hasUpperCase && hasLowerCase && hasDigit && hasSpecialChar;
        }

        private String checkPasswordStrength(String password) {
            if (password.isEmpty()) {
                return "Password is too weak";
            }

            if (isPasswordStrong(password)) {
                return "Strong Password";
            } else if (password.length() >= 7) {
                return "Medium Password (use uppercase letters, lowercase letters, numbers and a special character to make your password strong)";
            } else {
                return "Weak Password Your password must contain at least 7 characters";
            }
        }
    }
