//package com.example.project;
//
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.TextView;
//
//import androidx.recyclerview.widget.RecyclerView;
//
//import java.util.ArrayList;
//public class RewardAdapter extends RecyclerView.Adapter<RewardAdapter.RewardViewHolder> {
//
//    private ArrayList<String> rewardList;
//
//    public RewardAdapter(ArrayList<String> rewardsList) {
//        this.rewardList = rewardsList;
//    }
//
//    @Override
//    public RewardViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(parent.getContext()).inflate(android.R.layout.simple_list_item_1, parent, false);
//        return new RewardViewHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(RewardViewHolder holder, int position) {
//        holder.rewardTextView.setText(rewardsList.get(position));
//    }
//
//    @Override
//    public int getItemCount() {
//        return rewardsList.size();
//    }
//
//    public static class RewardViewHolder extends RecyclerView.ViewHolder {
//        public TextView rewardTextView;
//
//        public RewardViewHolder(View itemView) {
//            super(itemView);
//            rewardTextView = itemView.findViewById(android.R.id.text1);
//        }
//    }
//}
