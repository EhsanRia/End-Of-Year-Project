//package com.example.project;
//
//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import java.util.ArrayList;
//
//public class Reward extends AppCompatActivity {
//    private TextView userPoints;
//    private Button earnButton;
//    private RecyclerView rewardsRecyclerView;
//
//    private int userPoints = 0;
//    private ArrayList<String> rewardsList = new ArrayList<>();
//    private RewardAdapter rewardsAdapter;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_rewards);
//
//        userPoints = findViewById(R.id.userPoints);
//        earnButton = findViewById(R.id.earnButton);
//        rewardsRecyclerView = findViewById(R.id.rewardsRecyclerView);
//
//        rewardsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
//        rewardAdapter = new RewardAdapter(rewardList);
//        rewardsRecyclerView.setAdapter(rewardsAdapter);
//
//        // Set up earn points button listener
//        earnPointsButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                earnPoints();
//            }
//        });
//        loadInitialRewards();
//    }
//
//    private void earnPoints() {
//        userPoints += 10;
//
//        // Updating points
//        userPointsTextView.setText("Points: " + userPoints);
//
//        // Add a list of new reward when enough points are earned
//        rewardsList.add("Reward " + (rewardsList.size() + 1));
//        rewardsAdapter.notifyDataSetChanged();
//
//        // Show a toast to the user
//        Toast.makeText(this, "You earned 10 points!", Toast.LENGTH_SHORT).show();
//    }
//
//    private void loadInitialRewards() {
//        rewardsList.add("Reward 1");
//        rewardsList.add("Reward 2");
//        rewardsList.add("Reward 3");
//        rewardsAdapter.notifyDataSetChanged();
//    }
//}
