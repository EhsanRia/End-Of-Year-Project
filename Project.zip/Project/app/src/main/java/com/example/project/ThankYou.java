package com.example.project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ThankYou extends AppCompatActivity {

    private static final String PREFS_NAME = "UserPrefs";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_REWARD_POINTS = "reward_points";

    private TextView thankYouMessage;
    private Button backToHomeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.thank_you);

        thankYouMessage = findViewById(R.id.thankYouMessage);
        backToHomeButton = findViewById(R.id.backToHomeButton);

        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String userName = sharedPreferences.getString(KEY_USER_NAME, "User");
        int rewardPoints = sharedPreferences.getInt(KEY_REWARD_POINTS, 0);

        String message = "Thank you " + userName + " for ordering at Leeds Trinity University.\n" +
                "You now have " + rewardPoints + " points.";
        thankYouMessage.setText(message);

        backToHomeButton.setOnClickListener(v -> {
            Intent intent = new Intent(ThankYou.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
        });
    }
}
