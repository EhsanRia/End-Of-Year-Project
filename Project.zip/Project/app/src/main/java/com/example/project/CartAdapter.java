package com.example.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;

import java.util.ArrayList;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.viewholder> {
    ArrayList<Foods> list;
    private ManagementCart managementCart;
    ChangeNumberItemsListener changeNumberItemsListener;



    public CartAdapter(ArrayList<Foods> list, Context context , ChangeNumberItemsListener changeNumberItemsListener) {
        this.list = list;
        managementCart = new ManagementCart(context);
        this.changeNumberItemsListener = changeNumberItemsListener;
    }


    @NonNull
    @Override
    public CartAdapter.viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate= LayoutInflater.from(parent.getContext()).inflate(R.layout.viewholder_cart,parent,false);
        return new viewholder(inflate);
    }

    @Override
    public void onBindViewHolder(@NonNull CartAdapter.viewholder holder, int position) {
        Foods item = list.get(position);
        int quantity = item.getNumberInCart();
        double price = item.getPrice();
        double total = quantity * price;

        holder.title.setText(list.get(position).getTitle());
        holder.feeItem.setText("£" + list.get(position).getPrice());
        holder.totalItem.setText(quantity + " * £" + String.format("%.2f", price) + " = £" + String.format("%.2f", total));
        holder.num.setText(list.get(position).getNumberInCart() + "");

        Glide.with(holder.itemView.getContext())
                .load(list.get(position).getImagePath())
                .transform(new CenterCrop(), new RoundedCorners(30))
                .into(holder.picture);

        holder.plusCartButton.setOnClickListener(v -> managementCart.plusNumberItem(list, position, new ChangeNumberItemsListener() {
            @Override
            public void change() {
                notifyDataSetChanged();
                changeNumberItemsListener.change();
            }
        }));

        holder.minusCartButton.setOnClickListener(v -> managementCart.minusNumberItem(list, position, new ChangeNumberItemsListener() {
            @Override
            public void change() {
                notifyDataSetChanged();
                changeNumberItemsListener.change();
            }
        }));
    }


    @Override
    public int getItemCount() {
        return list.size();
    }

        public class viewholder extends RecyclerView.ViewHolder{
            TextView title, feeItem, minusCartButton, plusCartButton;
            ImageView picture;
            TextView totalItem, num;
            public viewholder(@NonNull View itemView) {
                super(itemView);

                title = itemView.findViewById(R.id.titleText);
                picture = itemView.findViewById(R.id.picture);
                feeItem = itemView.findViewById(R.id.feeItem);
                plusCartButton = itemView.findViewById(R.id.plusCartButton);
                minusCartButton = itemView.findViewById(R.id.minusCartButton);
                totalItem = itemView.findViewById(R.id.totalItem);
                num = itemView.findViewById(R.id.numberItem);

        }
    }
}
