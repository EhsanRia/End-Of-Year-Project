package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class Signup extends AppCompatActivity {

    // UI elements
    private FirebaseAuth firebaseAuth;
    private EditText fullName, email, password, confirmPassword;
    private Button signUpButton;
    private TextView passwordStrength, loginText;
    private ImageView eyeIconOff, eyeIconOn;
    private boolean isPasswordVisible = false;
    private boolean isConfirmPasswordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        firebaseAuth = FirebaseAuth.getInstance();

        // UI elements
        fullName = findViewById(R.id.fullName);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirmPassword);
        signUpButton = findViewById(R.id.signUpButton);
        passwordStrength = findViewById(R.id.passwordStrength);
        loginText = findViewById(R.id.loginText);
        eyeIconOff = findViewById(R.id.eyeIconOff);
        eyeIconOn = findViewById(R.id.eyeIconOn);

        loginText.setOnClickListener(v -> {
            Intent intent = new Intent(Signup.this, Login.class);
            startActivity(intent);
            finish();
        });

        eyeIconOff.setOnClickListener(v -> {
            if (isPasswordVisible) {
                password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                eyeIconOff.setImageResource(R.drawable.baseline_visibility_off_24);
                isPasswordVisible = false;
            } else {
                password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                eyeIconOff.setImageResource(R.drawable.baseline_visibilityon_24);
                isPasswordVisible = true;
            }
            password.setSelection(password.length());
        });

        eyeIconOn.setOnClickListener(v -> {
            if (isConfirmPasswordVisible) {
                confirmPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                eyeIconOn.setImageResource(R.drawable.baseline_visibility_off_24);
                isConfirmPasswordVisible = false;
            } else {
                confirmPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                eyeIconOn.setImageResource(R.drawable.baseline_visibilityon_24);
                isConfirmPasswordVisible = true;
            }
            confirmPassword.setSelection(confirmPassword.length());
        });

        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int after) {
                String passwordText = password.getText().toString();
                String strength = checkPasswordStrength(passwordText);
                passwordStrength.setText(strength);
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        // Sign Up Button listener
        signUpButton.setOnClickListener(v -> {
            String userFullName = fullName.getText().toString();
            String userEmail = email.getText().toString();
            String userPassword = password.getText().toString();
            String userConfirmPassword = confirmPassword.getText().toString();

            // Checking fields
            if (userFullName.isEmpty()) {
                Toast.makeText(Signup.this, "Please enter your full name", Toast.LENGTH_SHORT).show();
            } else if (!isValidFullName(userFullName)) {
                Toast.makeText(Signup.this, "Full name must contain first and last name (letters only)", Toast.LENGTH_SHORT).show();
            } else if (userEmail.isEmpty()) {
                Toast.makeText(Signup.this, "Please enter your email", Toast.LENGTH_SHORT).show();
            } else if (!isValidEmail(userEmail)) {
                Toast.makeText(Signup.this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
            } else if (userPassword.isEmpty()) {
                Toast.makeText(Signup.this, "Please enter your password", Toast.LENGTH_SHORT).show();
            } else if (userConfirmPassword.isEmpty()) {
                Toast.makeText(Signup.this, "Please confirm your password", Toast.LENGTH_SHORT).show();
            } else if (!userPassword.equals(userConfirmPassword)) {
                Toast.makeText(Signup.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            } else if (!isPasswordStrong(userPassword)) {
                Toast.makeText(Signup.this, "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character", Toast.LENGTH_SHORT).show();
            } else {
                // Proceed with sign-up
                Toast.makeText(Signup.this, "Sign Up successful", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Signup.this, MainActivity.class);
                intent.putExtra("fullName", userFullName);
                startActivity(intent);
                finish();
            }
        });
    }

    private boolean isPasswordStrong(String password) {
        boolean hasUpperCase = false;
        boolean hasLowerCase = false;
        boolean hasDigit = false;
        boolean hasSpecialChar = false;

        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (Character.isUpperCase(c)) hasUpperCase = true;
            if (Character.isLowerCase(c)) hasLowerCase = true;
            if (Character.isDigit(c)) hasDigit = true;
            if (!Character.isLetterOrDigit(c)) hasSpecialChar = true;
        }

        return hasUpperCase && hasLowerCase && hasDigit && hasSpecialChar;
    }

    private String checkPasswordStrength(String password) {
        if (password.isEmpty()) {
            return "Password is too weak";
        }

        if (isPasswordStrong(password)) {
            return "Strong Password";
        } else if (password.length() >= 7) {
            return "Medium Password (use uppercase letters, lowercase letters, numbers and a special character to make your password strong)";
        } else {
            return "Weak Password: Your password must contain at least 7 characters, one uppercase letter, one lowercase letter, one special character, and one number.";
        }
    }

    private boolean isValidEmail(String email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private boolean isValidFullName(String fullName) {
        String fullNamePattern = "^[A-Za-z]{2,}(\\s[A-Za-z]{2,})+$";
        return fullName.matches(fullNamePattern);
    }
}
