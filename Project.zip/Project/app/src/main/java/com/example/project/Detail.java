package com.example.project;

import android.os.Bundle;

import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import com.bumptech.glide.Glide;


public class Detail extends Basic {
    private Foods object;
    private int num = 1;
    private ManagementCart managementCart;
    private ImageView backButton, picture;
    private TextView priceText, titleText, descriptionText, rateText, totalText, numText, plusButton, minusButton,addButton;
    private RatingBar ratingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detail);

        getWindow().setStatusBarColor(getResources().getColor(R.color.black));
        getIntentExtra();
        setVariable();

    }

    private void setVariable() {
        // Initialize views
        backButton = findViewById(R.id.backButton);
        picture = findViewById(R.id.picture);
        priceText = findViewById(R.id.priceText);
        titleText = findViewById(R.id.titleText);
        descriptionText = findViewById(R.id.descriptionText);
        rateText = findViewById(R.id.rateText);
        ratingBar = findViewById(R.id.ratingBar);
        totalText = findViewById(R.id.totalText);
        plusButton = findViewById(R.id.plusButton);
        minusButton = findViewById(R.id.minusButton);
        addButton  = findViewById(R.id.addButton);
        numText = findViewById(R.id.numText);

        managementCart=new ManagementCart(this);
        backButton.setOnClickListener(v -> finish());

        Glide.with(Detail.this)
                .load(object.getImagePath())
                .into(picture);
        priceText.setText("£" + object.getPrice());
        titleText.setText(object.getTitle());
        descriptionText.setText(object.getDescription());
        rateText.setText(object.getStar() + "Rating");
        ratingBar.setRating((float) object.getStar());
        totalText.setText("£" + num * object.getPrice());

        plusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num=num+1;
                numText.setText(num+"");
                totalText.setText("£"+(num*object.getPrice()));
            }
        });

        minusButton.setOnClickListener(view -> {
            num=num-1;
            numText.setText(num+"");
            totalText.setText("£"+(num*object.getPrice()));
        });

        minusButton.setOnClickListener(view -> {
            if(num>1) {
                num = num - 1;
                numText.setText(num + "");
                totalText.setText("£" + (num * object.getPrice()));
            }
        });

        minusButton.setOnClickListener(view -> {
            if(num>1) {
                num = num - 1;
                numText.setText(num + "");
                totalText.setText("£" + (num * object.getPrice()));
            }
        });
        addButton.setOnClickListener(view -> {
            object.setNumberInCart(num);
            managementCart.insertFood(object);
        });
    }


private void getIntentExtra() {
    object = (Foods) getIntent().getSerializableExtra("object");
}
}