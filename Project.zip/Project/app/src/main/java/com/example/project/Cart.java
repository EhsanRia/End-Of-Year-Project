package com.example.project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class Cart extends AppCompatActivity {
    private static final String PREFS_NAME = "UserPrefs";
    private static final String KEY_REWARD_POINTS = "reward_points";
    private int earnedPoints = 0;

    private RecyclerView.Adapter adapter;
    private ManagementCart managementCart;
    private double tax;
    private ImageView backButton, logoImageView;
    private TextView subtotalFeeText, taxFeeText, totalFeeText, emptyText, rewardPointsTextView;
    private ScrollView scrollviewCart;
    private RecyclerView recyclerViewCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        // Initialize views
        backButton = findViewById(R.id.backButton);
        subtotalFeeText = findViewById(R.id.subtotalFeeText);
        taxFeeText = findViewById(R.id.taxFeeText);
        totalFeeText = findViewById(R.id.totalFeeText);
        emptyText = findViewById(R.id.emptyText);
        scrollviewCart = findViewById(R.id.scrollviewCart);
        recyclerViewCart = findViewById(R.id.cardView);
        logoImageView = findViewById(R.id.logoImageView);
        rewardPointsTextView = findViewById(R.id.rewardPointsValue);

        managementCart = new ManagementCart(this);

        setVariable();
        calculateCart();
        initList();
    }

    private void initList() {
        // Check if cart is empty
        if (managementCart.getListCart().isEmpty()) {
            emptyText.setVisibility(View.VISIBLE);
            scrollviewCart.setVisibility(View.GONE);
        } else {
            emptyText.setVisibility(View.GONE);
            scrollviewCart.setVisibility(View.VISIBLE);
        }

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerViewCart.setLayoutManager(linearLayoutManager);
        adapter = new CartAdapter(managementCart.getListCart(), this, () -> calculateCart());
        recyclerViewCart.setAdapter(adapter);
    }

    private void calculateCart() {
        // Tax calculation
        double percentageTax = 0.02;
        tax = Math.round(managementCart.getTotalFee() * percentageTax * 100) / 100.0;

        double itemTotal = Math.round(managementCart.getTotalFee() * 100) / 100.0;
        double total = Math.round((itemTotal + tax) * 100) / 100.0;

        subtotalFeeText.setText(String.format("£%.2f", itemTotal));
        taxFeeText.setText(String.format("£%.2f", tax));
        totalFeeText.setText(String.format("£%.2f", total));

        earnedPoints = (int) (total * 10);

        rewardPointsTextView.setText(String.valueOf(earnedPoints));
    }

    private void setVariable() {
        backButton.setOnClickListener(view -> finish());
        logoImageView.setOnClickListener(view -> finish());

        findViewById(R.id.button1).setOnClickListener(view -> {
            SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            int currentPoints = sharedPreferences.getInt(KEY_REWARD_POINTS, 0);
            int newTotalPoints = currentPoints + earnedPoints;

            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putInt(KEY_REWARD_POINTS, newTotalPoints);
            editor.apply();

            Toast.makeText(Cart.this, "Congratulations! You earned " + earnedPoints + " points!", Toast.LENGTH_SHORT).show();

            managementCart.clearCart();

            // Move to ThankYou page
            Intent intent = new Intent(Cart.this, ThankYou.class);
            intent.putExtra("earned_points", earnedPoints);
            startActivity(intent);
            finish();
        });
}

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int savedPoints = sharedPreferences.getInt(KEY_REWARD_POINTS, 0);
        rewardPointsTextView.setText(String.valueOf(savedPoints));
    }
}