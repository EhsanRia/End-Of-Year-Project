package com.example.project;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Welcome extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);

        getWindow().setStatusBarColor(Color.parseColor("#FFE4B5"));


        Button signinButton = findViewById(R.id.Signin);
        Button signupButton = findViewById(R.id.SignUp);

        signinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to SignIn
                Intent intent = new Intent(Welcome.this, Login.class);
                startActivity(intent);
            }
        });

//        signupButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // Navigate to SignUp
//                Intent intent = new Intent(Welcome.this, SignUpActivity.class);
//                startActivity(intent);
//            }
//        });
    }
}
