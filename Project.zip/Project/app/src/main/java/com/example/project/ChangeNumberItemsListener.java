package com.example.project;

public interface ChangeNumberItemsListener {
    void change();
}
