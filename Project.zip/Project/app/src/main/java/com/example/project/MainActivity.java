package com.example.project;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Spinner locationSp, timeSp, moneySp;
    private RecyclerView FavouriteFoodView, categoryView;
    private ProgressBar progressBarFeatured, categoryProgressbar;
    private ImageView SearchButton, logoutButton, CartB;
    private EditText searchEdit;
    private TextView rewardPointsText, welcomeText;

    private static final String PREFS_NAME = "UserPrefs";
    private static final String KEY_REWARD_POINTS = "reward_points";
    private static final String KEY_USER_EMAIL = "user_email";

    private static final String PREFS_LAUNCH = "AppPrefs";
    private static final String KEY_LAUNCH_COUNT = "LaunchCount";
    private static final String KEY_HAS_GOTTEN_REWARD = "HasGottenFirstReward";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        locationSp = findViewById(R.id.LocationSpin);
        timeSp = findViewById(R.id.TimeSpin);
        moneySp = findViewById(R.id.MoneySpin);
        FavouriteFoodView = findViewById(R.id.FavouriteFoodView);
        categoryView = findViewById(R.id.categoryView);
        progressBarFeatured = findViewById(R.id.progressBarFeatured);
        categoryProgressbar = findViewById(R.id.categoryProgressbar);
        logoutButton = findViewById(R.id.logoutButton);
        SearchButton = findViewById(R.id.SearchB);
        searchEdit = findViewById(R.id.searchEdit);
        CartB = findViewById(R.id.CartB);
        rewardPointsText = findViewById(R.id.rewardPointsText);
        welcomeText = findViewById(R.id.welcomeText);

        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String userEmail = sharedPreferences.getString(KEY_USER_EMAIL, "");

        if (!userEmail.isEmpty()) {
            String userName = userEmail.split("@")[0];
            welcomeText.setText("Hello " + userName);
        }

        String fullName = getIntent().getStringExtra("fullName");
        if (fullName != null && !fullName.isEmpty()) {
            welcomeText.setText("Welcome, " + fullName);
        }

        initLocation();
        initTime();
        initMoney();
        initFavouriteFood();
        initCategory();
        setVariable();
        loadRewardPoints();
        handleLaunchRewards();
    }

    private void handleLaunchRewards() {
        SharedPreferences prefs = getSharedPreferences(PREFS_LAUNCH, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        int launchCount = prefs.getInt(KEY_LAUNCH_COUNT, 0);
        boolean hasGottenFirstReward = prefs.getBoolean(KEY_HAS_GOTTEN_REWARD, false);

        launchCount++;
        editor.putInt(KEY_LAUNCH_COUNT, launchCount);
        editor.apply();

        if (launchCount == 1 && !hasGottenFirstReward) {
            Toast.makeText(this, "Welcome! You have earned 10 points!", Toast.LENGTH_LONG).show();
            addRewardPoints(10);

            editor.putBoolean(KEY_HAS_GOTTEN_REWARD, true);
            editor.apply();
        } else if (launchCount == 5) {
            Toast.makeText(this, "Welcome back! Thank you for using the app!", Toast.LENGTH_LONG).show();
        } else if (launchCount == 10) {
            Toast.makeText(this, "Thank you for regularly using the app!", Toast.LENGTH_LONG).show();
        }
    }

    private void addRewardPoints(int pointsToAdd) {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        int currentPoints = sharedPreferences.getInt(KEY_REWARD_POINTS, 0);
        currentPoints += pointsToAdd;
        editor.putInt(KEY_REWARD_POINTS, currentPoints);
        editor.apply();

        rewardPointsText.setText("Your Points: " + currentPoints);
    }

    private void setVariable() {
        logoutButton.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(MainActivity.this, Login.class));
        });

        SearchButton.setOnClickListener(v -> {
            String text = searchEdit.getText().toString();
            if (!text.isEmpty()) {
                Intent intent = new Intent(MainActivity.this, FoodLists.class);
                intent.putExtra("text", text);
                intent.putExtra("isSearch", true);
                startActivity(intent);
            }
        });

        CartB.setOnClickListener(view -> startActivity(new Intent(MainActivity.this, Cart.class)));
    }

    private void initFavouriteFood() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Foods");
        progressBarFeatured.setVisibility(View.VISIBLE);
        ArrayList<Foods> list = new ArrayList<>();
        Query query = myRef.orderByChild("BestFood").equalTo(true);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot issue : snapshot.getChildren()) {
                        list.add(issue.getValue(Foods.class));
                    }
                    if (list.size() > 0) {
                        FavouriteFoodAdapter adapter = new FavouriteFoodAdapter(list);
                        FavouriteFoodView.setLayoutManager(new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false));
                        FavouriteFoodView.setAdapter(adapter);
                    }
                }
                progressBarFeatured.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });
    }

    private void initCategory() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Category");
        categoryProgressbar.setVisibility(View.VISIBLE);
        ArrayList<Category> list = new ArrayList<>();
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot issue : snapshot.getChildren()) {
                        list.add(issue.getValue(Category.class));
                    }
                    if (list.size() > 0) {
                        CategoryAdapter adapter = new CategoryAdapter(list);
                        categoryView.setLayoutManager(new GridLayoutManager(MainActivity.this, 4));
                        categoryView.setAdapter(adapter);
                    }
                }
                categoryProgressbar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });
    }

    private void initLocation() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Location");
        ArrayList<Location> list = new ArrayList<>();
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot issue : snapshot.getChildren()) {
                        list.add(issue.getValue(Location.class));
                    }
                    ArrayAdapter<Location> adapter = new ArrayAdapter<>(MainActivity.this, R.layout.sp_item, list);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    locationSp.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });
    }

    private void initTime() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Time");
        ArrayList<Time> list = new ArrayList<>();
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot issue : snapshot.getChildren()) {
                        list.add(issue.getValue(Time.class));
                    }
                    ArrayAdapter<Time> adapter = new ArrayAdapter<>(MainActivity.this, R.layout.sp_item, list);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    timeSp.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });
    }

    private void initMoney() {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("Price");
        ArrayList<Price> list = new ArrayList<>();
        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot issue : snapshot.getChildren()) {
                        list.add(issue.getValue(Price.class));
                    }
                    ArrayAdapter<Price> adapter = new ArrayAdapter<>(MainActivity.this, R.layout.sp_item, list);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    moneySp.setAdapter(adapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });
    }

    private void loadRewardPoints() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int rewardPoints = sharedPreferences.getInt(KEY_REWARD_POINTS, 0);
        rewardPointsText.setText("Your Points: " + rewardPoints);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadRewardPoints();
    }
}
