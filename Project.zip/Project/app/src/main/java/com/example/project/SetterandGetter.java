package com.example.project;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SetterandGetter extends Basic {

    private Button loginBtn, signupBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        // Initialize UI components using findViewById()
        loginBtn = findViewById(R.id.LogInButton);
        signupBtn = findViewById(R.id.signUpButton);

        setVariable();
        getWindow().setStatusBarColor(Color.parseColor("#FFE4B5"));
    }

    private void setVariable() {
        // Set onClick listeners for login and signup buttons
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mAuth.getCurrentUser() != null) {
                    // If user is logged in, start MainActivity
                    startActivity(new Intent(SetterandGetter.this, MainActivity.class));
                } else {
                    // If no user is logged in, start Login activity
                    startActivity(new Intent(SetterandGetter.this, Login.class));
                }
            }
        });

        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // When signup button is clicked, start Welcome activity
                startActivity(new Intent(SetterandGetter.this, Welcome.class));
            }
        });
    }
}
